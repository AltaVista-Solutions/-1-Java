package com.sample.springmvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sample.springmvc.Models.Product;

@Controller
public class HomeController {

	public static List<Product> productlist=new ArrayList<Product>();
	static {
		productlist.add(new Product(1,"Test Product 1",25000));
		productlist.add(new Product(2,"Test Product 2",36000));
		productlist.add(new Product(3,"Test Product 3",41500));
		productlist.add(new Product(4,"Test Product 4",58600));
		productlist.add(new Product(5,"Test Product 5",25200));
	}
	
	
//	@RequestMapping(value="/")
//	public ModelAndView test(HttpServletResponse response) throws IOException{
//		return new ModelAndView("home");
//	}
	
	@RequestMapping(value="/",method = RequestMethod.GET)
	public ModelAndView GetProductList(HttpServletResponse response)
	{
		ModelAndView mav=new ModelAndView("home");
		mav.addObject("products", productlist);
		return mav;
	}
	
	@RequestMapping(value="/add",method = RequestMethod.GET)
	public String addProduct()
	{
		return "Add";
	}
	
	@RequestMapping(value="/add",method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product")Product prod)
	{
		productlist.add(prod);
		return "redirect:/";
	}
	
	@RequestMapping(value="/delete/{id}",method = RequestMethod.GET)
	public String deleteProduct(@PathVariable int id)
	{
		Product prod=getProductById(id);
		productlist.remove(prod);
		return "redirect:/";
	}
	
	private Product getProductById(int id)
	{
		for(Product prod:productlist)
		{
			if(prod.getId()==id)
			{
				return prod;
			}
		}
		return null;
	}
}
