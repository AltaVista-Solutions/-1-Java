package com.sample;

public class CITI implements Bank {
	private double ROI;
    private String CountryName;
    
    
	
	public CITI(double rOI, String countryName) {
		super();
		ROI = rOI;
		CountryName = countryName;
	}

	


	@Override
	public String toString() {
		return "CITI [ROI=" + ROI + ", CountryName=" + CountryName + "]";
	}




	@Override
	public void GetROI() {
		System.out.println("This is From CITI Class");

	}

}
