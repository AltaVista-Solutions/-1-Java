package com.sample;

public class Department {
	private int DId;
	private String Name;
	public int getDId() {
		return DId;
	}
	public void setDId(int dId) {
		DId = dId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Department(int dId, String name) {
		super();
		DId = dId;
		Name = name;
	}
	@Override
	public String toString() {
		return "Department [DId=" + DId + ", Name=" + Name + "]";
	}
	
	
}
