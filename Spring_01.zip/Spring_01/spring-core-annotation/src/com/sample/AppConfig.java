package com.sample;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean
	public Department getDep()
	{
		return new Department(9001, "IT-Dev");
	}
	
	@Bean
	public Employee getEmp()
	{
		Department dep=this.getDep();
		return new Employee(1, "John", 55000, dep);
	}
}
