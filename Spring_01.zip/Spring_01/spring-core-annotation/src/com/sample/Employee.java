package com.sample;

public class Employee {
	private int Id;
	private String Name;
	private double Salary;
	private Department department;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee(int id, String name, double salary, Department department) {
		super();
		Id = id;
		Name = name;
		Salary = salary;
		this.department = department;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary + ", department=" + department + "]";
	}
	
	
}
