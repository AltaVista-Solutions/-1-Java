package com.sample;

import javax.sql.DataSource;

import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.*;

@Configuration
public class AppConfig {
	
	@Bean
	public DataSource datasource()
	{
		DriverManagerDataSource ds=new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost:3306/StoreDB");
		ds.setUsername("root");
		ds.setPassword("123456");		
		return ds;
	}
	
	@Bean
	public ProductDAO getProductDAO()
	{
		return new ProductDAO(new JdbcTemplate(datasource()));
	}
}
