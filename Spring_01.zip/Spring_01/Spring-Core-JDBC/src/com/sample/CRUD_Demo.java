package com.sample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CRUD_Demo {

	public static void Insert()
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
		
		Product prod=new Product();
		prod.setId(101);
		prod.setName("Iphone 15");
		prod.setPrice(78500);
		dao.Add(prod);
	}
	public static void GetData()
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		ProductDAO dao=(ProductDAO)context.getBean(ProductDAO.class);
		
		 for(Product prod: dao.GetProducts())
		 {
			 System.out.println(prod.getId()+"-"+prod.getName()+"-"+prod.getPrice());
		 }
	}
	public static void main(String[] args) {
		
		GetData();
	}

}
