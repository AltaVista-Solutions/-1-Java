package com.sample;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class ProductDAO {
   private final JdbcTemplate jdbctemplate;

@Autowired   
public ProductDAO(JdbcTemplate jdbctemplate) {
	super();
	this.jdbctemplate = jdbctemplate;
}
   
public void Add(Product prod)
{
	String query="insert into products(id,name,price)values(?,?,?)";
	int _rows=jdbctemplate.update(query,prod.getId(),prod.getName(),prod.getPrice());
	System.out.println(_rows+" Row(s) Inserted Successfully!");
}

public void Update(Product prod)
{
	String query="update products set name=?,price=? where id=?";
	int _rows=jdbctemplate.update(query,prod.getName(),prod.getPrice(),prod.getId());
	System.out.println(_rows+" Row(s) Updated Successfully!");
}

public void Delete(int id)
{
	String query="delete from products where id=?";
	int _rows=jdbctemplate.update(query,id);
	System.out.println(_rows+" Row(s) Deleted Successfully!");
}

public List<Product> GetProducts()
{
	String query="select * from products";
	List<Product> Prods= jdbctemplate.query(query,new ProductRowMapper());
	System.out.println("---------------------------");
	System.out.println("Rows Available:"+Prods.size());
	System.out.println("---------------------------");
	return Prods;
}
   
}
