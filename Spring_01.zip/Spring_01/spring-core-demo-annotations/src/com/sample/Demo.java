package com.sample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {

	public static void main(String[] args) {
		ApplicationContext factory=new ClassPathXmlApplicationContext("spring.xml");
		Bank obj=(Bank)factory.getBean(HDFC.class);
		obj.GetROI();
		System.out.println(obj);

	}

}
