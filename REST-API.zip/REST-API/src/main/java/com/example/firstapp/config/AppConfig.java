package com.example.firstapp.config;

import org.springframework.context.annotation.*;

import com.example.firstapp.services.EmployeeService;
import com.example.firstapp.services.EmployeeServiceImpl;

@Configuration
public class AppConfig {
	
	@Bean
	public EmployeeService getEmployeesRepository()
	{
		return new EmployeeServiceImpl();
	}
}
