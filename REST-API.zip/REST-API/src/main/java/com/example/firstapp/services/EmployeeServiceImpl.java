package com.example.firstapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.firstapp.models.Employee;
import com.example.firstapp.repos.EmployeesRepository;

public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeesRepository repo;
	
	@Override
	public List<Employee> GetAllEmployees() {
		return repo.findAll();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public void deleteEmployee(Employee emp) {
		repo.delete(emp);

	}

	@Override
	public Employee getEmployeeById(int id) {
		return repo.findById(id).get();
	}

}
