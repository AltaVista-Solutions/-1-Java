package com.example.firstapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.firstapp.models.Employee;
import com.example.firstapp.services.EmployeeService;

@RestController
public class EmployeesController 
{
	@Autowired
	private EmployeeService serv;
	
	@GetMapping("/")
	public ResponseEntity<List<Employee>> getAllEmployees()
	{
		List<Employee> emps= serv.GetAllEmployees();
		return ResponseEntity.status(HttpStatus.OK).body(emps);
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployee(@PathVariable int id)
	{
		Employee emp= serv.getEmployeeById(id);
		return ResponseEntity.status(HttpStatus.OK).body(emp);
	}
	
	@PostMapping("/")
	public ResponseEntity<Employee> Add(@RequestBody Employee emp)
	{
		Employee empRes=serv.addEmployee(emp);
		return ResponseEntity.status(HttpStatus.CREATED).body(empRes);
	}
	
	
	@PutMapping("/")
	public ResponseEntity<Employee> Update(@RequestBody Employee emp)
	{
		Employee empRes=serv.updateEmployee(emp);
		return ResponseEntity.status(HttpStatus.OK).body(empRes);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> Delete(@PathVariable int id)
	{
		serv.deleteEmployee(serv.getEmployeeById(id));
		return ResponseEntity.ok("Deleted Successfully!");
	}
}
