package com.example.firstapp.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.firstapp.models.Employee;

public interface EmployeesRepository extends JpaRepository<Employee, Integer> {

}
