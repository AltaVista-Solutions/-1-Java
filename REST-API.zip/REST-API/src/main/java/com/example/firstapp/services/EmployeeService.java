package com.example.firstapp.services;

import java.util.List;

import com.example.firstapp.models.Employee;

public interface EmployeeService {
	public List<Employee> GetAllEmployees();
	public Employee addEmployee(Employee emp);
	public Employee updateEmployee(Employee emp);
	public void deleteEmployee(Employee emp);
	public Employee getEmployeeById(int id);
}
